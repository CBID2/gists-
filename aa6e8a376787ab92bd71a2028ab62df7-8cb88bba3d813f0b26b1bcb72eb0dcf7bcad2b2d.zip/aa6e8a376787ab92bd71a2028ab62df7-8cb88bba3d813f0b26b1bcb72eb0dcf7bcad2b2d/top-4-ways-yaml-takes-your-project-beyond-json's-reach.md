# Authors Guide: Article Template

_Please submit your article including all of the information below. You can include this as a seperate file if you like - but please complete each section. Please use an online service to write your article, for example Dropbox Paper, Draft.in, Google Docs. For more help, see the [editorial guide](https://www.smashingmagazine.com/editorial-process/)_

**Article Title**

Ideally under 67 characters, what problem does this article solve?

**Quick Summary**

This should be a paragraph that will be placed above the article summarizing what the reader will learn by reading your article. Why should they take the time? Convince them!

**Article Content**

Add your article here. Don’t forget to write an introduction that explains what you will be covering, and a conclusion that gives some additional resources or sums up the things learned. See our Style Guide for more: https://www.smashingmagazine.com/style-guide/ 

Things you can include (in addition to regular text formatting):

**Headings**

The main article heading is an h1, i.e. a level 1 heading. Use level 2 (h2) and level 3 (h3) headings to break up your text.

**Code**

This can be inline or you can embed a CodePen.

**Images**

Standard images need to be at least 800px wide, we also have the option of full-width images for very detailed views. Also, please do not optimize them. If you’re using Dropbox Paper or Google docs then add your images inline but please also add them to the list at the end of this template, so we can be sure we have them all in high-res format.

**Tables**

These can be helpful if you have data to share. Remember to give rows and columns good headings, and include a caption for any data table.

## Before sending your draft, add the following information:

**Pull Quotes**

Please highlight two pieces of text (no more than 40 words each) from the article that you think would make a good standalone pull quote, to help engage a reader with your article.

Also, if there’s a quote you’d like us to use for the article’s sharing image for Smashing’s social media channels, you can add a note here.

**List of included images**

List all images included in the article below. When you send your final draft we will need a zip of all of the original images. They need to be at least 800px wide. Add details for each image as follows:

- Image file: my-image.png
- Image caption: A caption to be shown below the image
- Image Alt: A description of what the image shows for alt text

**Author Bio**

Please add your bio here. If you have written for Smashing before then just add a line to use existing bio.

**Author Photo**

Image file: my-lovely-headshot.jpg
(or tell us to use your existing one)

**Author Links**

Two or three ways to find you, e.g. Twitter, your personal site, LinkedIn, anywhere. Or ask us to use existing.